<?if(!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<?
IncludeTemplateLangFile(__FILE__);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru" lang="ru">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<?$APPLICATION->ShowHead();?>
	<link href="<?=SITE_TEMPLATE_PATH?>/common.css" type="text/css" rel="stylesheet" />
	<link href="<?=SITE_TEMPLATE_PATH?>/colors.css" type="text/css" rel="stylesheet" />
	<link href="/include/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<!--[if lte IE 6]>
	<style type="text/css">

		div.product-overlay {
			background-image: none;
			filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='<?=SITE_TEMPLATE_PATH?>images/product-overlay.png', sizingMethod = 'crop');
		}

	</style>
	<![endif]-->

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
	<script src="/include/validate/jquery.validate.js"></script>

	<title><?$APPLICATION->ShowTitle()?></title>
</head>
<body>

	<?
		require_once($_SERVER["DOCUMENT_ROOT"] . '/include/bav.php');
	?>

	<div id="page-wrapper">
		<div id="panel"><?$APPLICATION->ShowPanel();?></div>

		<!-- Объявление над шапкой -->
		<div class="row">
			<div class="col-xs-12 text-center alert alert-danger">
						<h3>Сайт в процессе разработки...</h3>
			</div>
		</div>
		<!-- // Объявление над шапкой -->

		<div id="header">

			<table id="logo">
				<tr>
					<td><a href="<?=SITE_DIR?>" title="<?=GetMessage('CFT_MAIN')?>"><?
$APPLICATION->IncludeFile(
	SITE_DIR."include/company_name.php",
	Array(),
	Array("MODE"=>"html")
);
?></a></td>
				</tr>
			</table>

			<div id="top-menu">
				<div id="top-menu-inner">
<?$APPLICATION->IncludeComponent(
	"bitrix:menu", 
	"horizontal_multilevel_book", 
	array(
		"ROOT_MENU_TYPE" => "top",
		"MAX_LEVEL" => "2",
		"CHILD_MENU_TYPE" => "left",
		"USE_EXT" => "Y",
		"MENU_CACHE_TYPE" => "A",
		"MENU_CACHE_TIME" => "36000000",
		"MENU_CACHE_USE_GROUPS" => "Y",
		"MENU_CACHE_GET_VARS" => array(
		),
		"DELAY" => "N",
		"ALLOW_MULTI_SELECT" => "N"
	),
	false,
	array(
		"ACTIVE_COMPONENT" => "Y"
	)
);?>
				</div>
			</div>

			<div class="row"  id="top-icons">
				<div class="col-xs-12">
					<div class="btn-group btn-group-sm">
						<a class="btn btn-default" href="/" title="На главную"><span class="glyphicon glyphicon-home"></span> </a>
						<a class="btn btn-default" href="/contacts/" title="Контакты"><span class="glyphicon glyphicon-envelope"></span> </a>
						<?if ($USER->IsAuthorized()):?>
							<a class="btn btn-default" href="/?logout=yes" title="Выход"><span class="glyphicon glyphicon-log-out"></span> </a>
						<?else:?>
							<a class="btn btn-default" href="/auth/" title="Вход"><span class="glyphicon glyphicon-log-in"></span> </a>
						<?endif;?>
					</div>
					<?if ($USER->IsAuthorized()):?>
						<span class="current-user">(<?=$USER->GetFullName()?>)</span>
					<?endif;?>
				</div>
			</div>

		</div>

		<div class="main_block">
			<div class="row">
				<div class="col-xs-3 text-center">
					<img src="/bitrix/templates/books/images/logo.png" width="209" height="71" border="0">
				</div>
				<div class="col-xs-9">
					<?$APPLICATION->IncludeComponent(
						"bitrix:menu",
						"horizontal_multilevel_new",
						array(
							"ROOT_MENU_TYPE" => "top",
							"MAX_LEVEL" => "2",
							"CHILD_MENU_TYPE" => "left",
							"USE_EXT" => "Y",
							"MENU_CACHE_TYPE" => "A",
							"MENU_CACHE_TIME" => "36000000",
							"MENU_CACHE_USE_GROUPS" => "Y",
							"MENU_CACHE_GET_VARS" => array(
							),
							"DELAY" => "N",
							"ALLOW_MULTI_SELECT" => "N"
						),
						false,
						array(
							"ACTIVE_COMPONENT" => "Y"
						)
					);?>
				</div>
			</div>
		</div>

		<div id="banner">
			Заказ учебников для образовательных организаций
		</div>

		<div id="content">

			<div id="sidebar">
			<!-- Левая колонка -->

			<!-- Меню администратора -->
			<?if (is_user_in_group(7) || is_user_in_group(6)):?>
				<div class="panel panel-default">
					<div class="panel-heading"><div class="panel-title">Администратор</div></div>
					<div class="panel-body">
<?$APPLICATION->IncludeComponent(
	"bitrix:menu",
	"left",
	array(
		"ROOT_MENU_TYPE" => "admin",
		"MENU_CACHE_TYPE" => "N",
		"MENU_CACHE_TIME" => "36000000",
		"MENU_CACHE_USE_GROUPS" => "Y",
		"MENU_CACHE_GET_VARS" => array(
		),
		"MAX_LEVEL" => "1",
		"CHILD_MENU_TYPE" => "left",
		"USE_EXT" => "N",
		"ALLOW_MULTI_SELECT" => "N",
		"DELAY" => "N"
	),
	false,
	array(
		"ACTIVE_COMPONENT" => "Y"
	)
);?>
					</div>
				</div>
			<?endif;?>
			<!-- // Меню администратора -->

			<!-- Меню оператора -->
			<?if (is_user_in_group(9) || is_user_in_group(1)):?>
				<div class="panel panel-default">
					<div class="panel-heading"><div class="panel-title">Оператор</div></div>
					<div class="panel-body">
<?$APPLICATION->IncludeComponent(
	"bitrix:menu",
	"left",
	array(
		"ROOT_MENU_TYPE" => "oper",
		"MENU_CACHE_TYPE" => "N",
		"MENU_CACHE_TIME" => "36000000",
		"MENU_CACHE_USE_GROUPS" => "Y",
		"MENU_CACHE_GET_VARS" => array(
		),
		"MAX_LEVEL" => "1",
		"CHILD_MENU_TYPE" => "left",
		"USE_EXT" => "N",
		"ALLOW_MULTI_SELECT" => "N",
		"DELAY" => "N"
	),
	false,
	array(
		"ACTIVE_COMPONENT" => "Y"
	)
);?>
					</div>
				</div>
			<?endif;?>
			<!-- // Меню оператора -->

			<!-- Личный кабинет -->
			<?$school_id = get_schoolID($USER->GetID());?>
			<?if (is_user_in_group(8) && $school_id):?>
				<div class="panel panel-default personal-cabinet">
					<div class="panel-heading"><div class="panel-title"><?=get_schoolName($USER->GetID())?></div></div>
					<div class="panel-body">
						<div class="row cart-data">
							<div class="col-xs-6">В корзине:</div>
							<div class="col-xs-6 text-right" id="cart_sum">0&nbsp;руб.</div>
						</div>
						<div class="btn-group button-panel">
						  <a href="/orders/basket/" class="btn btn-primary btn-lg" title="Корзина"><span class="glyphicon glyphicon-shopping-cart"></span> </a>
						  <a href="/orders/" class="btn btn-primary btn-lg" title="Заказы"><span class="glyphicon glyphicon-folder-open"></span> </a>
						  <a href="/schools/<?=$school_id;?>/" class="btn btn-primary btn-lg" title="Реквизиты школы"><span class="glyphicon glyphicon-list-alt"></span> </a>
						  <a href="/?logout=yes" class="btn btn-primary btn-lg" title="Выход"><span class="glyphicon glyphicon-log-out"></span> </a>
						</div>
					</div>
				</div>
				<script type="text/javascript" language="javascript">
					$(document).ready(function(){
						// загрузка данных корзины
						$.ajax({
							url: "/include/ajax/get_cart_info.php",
							method: "POST",
							data: {"USER" : <?=$USER->GetID();?>},
							cache: false,
							beforeSend: function(){
								$("#cart_sum").html('<img src="/bitrix/templates/books/images/loading.png" border="0" width="16" height="16">');
							},
							success: function(data){
								var result = jQuery.parseJSON(data);
								$("#cart_sum").html(result.sum);
							},
							error: function(){
								$("#cart_sum").html('Ошибка');
							}
						});
					});

					function add_to_cart(book_id) {
						// Проверяем указанное количество
						cnt = Number($("#book_counter_" + book_id).val());
						if (isNaN(cnt) || cnt < 1) {
							alert('Неверно указано количество!');
						} else {
							// добавление книги в корзину и обновление данных корзины
							$.ajax({
								url: "/include/ajax/add_to_cart.php",
								method: "POST",
								data: {"USER" : <?=$USER->GetID();?>, "BOOK" : book_id, "COUNT" : cnt},
								cache: false,
								beforeSend: function(){
//									$("#cart_count").html('<img src="/bitrix/templates/books/images/loading.png" border="0" width="16" height="16">');
									$("#cart_sum").html('<img src="/bitrix/templates/books/images/loading.png" border="0" width="16" height="16">');
								},
								success: function(data){
									var result = jQuery.parseJSON(data);
//									$("#count_book_" + book_id).html(result.count_book);
									$("#del_book_" + book_id).removeAttr("hidden");
									$("#add_book_" + book_id).attr("hidden","hidden");
//									$("#cart_count").html(result.count);
									$("#cart_sum").html(result.sum);
								},
								error: function(){
									$("#cart_count").html('Ошибка!');
									$("#cart_sum").html('Ошибка!');
								}
							});
						}
					}

					function del_from_cart(book_id) {
						// удаление книги и обновление данных корзины
						$.ajax({
							url: "/include/ajax/del_from_cart.php",
							method: "POST",
							data: {"USER" : <?=$USER->GetID();?>, "BOOK" : book_id},
							cache: false,
							beforeSend: function(){
//								$("#cart_count").html('<img src="/bitrix/templates/books/images/loading.png" border="0" width="16" height="16">');
								$("#cart_sum").html('<img src="/bitrix/templates/books/images/loading.png" border="0" width="16" height="16">');
							},
							success: function(data){
								var result = jQuery.parseJSON(data);
								$("#add_book_" + book_id).removeAttr("hidden");
								$("#del_book_" + book_id).attr("hidden","hidden");
//								$("#cart_count").html(result.count);
								$("#cart_sum").html(result.sum);
							},
							error: function(){
								$("#cart_count").html('Ошибка!');
								$("#cart_sum").html('Ошибка!');
							}
						});
					}
				</script>
			<?endif;?>
			<!-- // Личный кабинет -->

			<!-- Меню издательств -->
				<div class="panel panel-default">
					<div class="panel-heading"><div class="panel-title">Издательства</div></div>
					<div class="panel-body">
<?$APPLICATION->IncludeComponent(
	"bitrix:menu",
	"left",
	array(
		"ROOT_MENU_TYPE" => "left",
		"MENU_CACHE_TYPE" => "A",
		"MENU_CACHE_TIME" => "36000000",
		"MENU_CACHE_USE_GROUPS" => "Y",
		"MENU_CACHE_GET_VARS" => array(
		),
		"MAX_LEVEL" => "1",
		"CHILD_MENU_TYPE" => "left",
		"USE_EXT" => "N",
		"ALLOW_MULTI_SELECT" => "N",
		"DELAY" => "N"
	),
	false,
	array(
		"ACTIVE_COMPONENT" => "Y"
	)
);?>
						</div>
					</div>
			<!-- // Меню издательств -->

			<!-- Новое на сайте -->
				<div class="panel panel-default">
					<div class="panel-heading"><div class="panel-title">Новое на сайте</div></div>
					<div class="panel-body">
	<?
	$APPLICATION->IncludeFile(
		SITE_DIR."include/site_news.php",
		Array(),
		Array("MODE"=>"html")
	);
	?>
					</div>
				</div>
				<!-- Новое на сайте -->



				<!-- Новости -->
					<div class="panel panel-default">
						<div class="panel-heading"><div class="panel-title">Новости</div></div>
						<div class="panel-body">
	<?
	$APPLICATION->IncludeFile(
		SITE_DIR."include/news.php",
		Array(),
		Array("MODE"=>"html")
	);
	?>
						</div>
					</div>
					<!-- Новости -->

<?if (0):?>
				<div class="information-block">
					<div class="top"></div>
					<div class="information-block-inner">
						Информационный блок
					</div>
					<div class="bottom"></div>
				</div>
<?endif;?>

			<!-- // Левая колонка -->
			</div>

			<div id="workarea">
<?if (false):?>				<h2 id="pagetitle"><?$APPLICATION->ShowTitle(false);?></h2>		<?endif;?>